const express = require('express');
const jwt = require('jsonwebtoken');
const router = express.Router();

const { tickets } = require('../data');
const SECRET_KEY = 'secret_key';

const authenticateToken = (req, res, next) => {
    const token = req.headers['authorization'];
    if (!token) return res.sendStatus(403);

    jwt.verify(token, SECRET_KEY, (err, user) => {
        if (err) return res.sendStatus(403);
        req.user = user;
        next();
    });
};

/**
 * @swagger
 * tags:
 *   name: Tickets
 *   description: Ticket management
 */

/**
 * @swagger
 * /tickets/{eventId}:
 *   get:
 *     summary: List available tickets for an event
 *     tags: [Tickets]
 *     parameters:
 *       - in: path
 *         name: eventId
 *         required: true
 *         schema:
 *           type: integer
 *         description: The event ID
 *     security:
 *       - simpleAuth: []
 *     responses:
 *       200:
 *         description: List of available tickets
 *       401:
 *         description: Forbidden
 */
router.get('/:eventId', authenticateToken, (req, res) => {
    const eventTickets = tickets.filter(ticket => {
        return ticket.eventId === parseInt(req.params.eventId) && !ticket.reserved;
    });
    res.json(eventTickets);
});

/**
 * @swagger
 * /tickets/{eventId}/seat/{seatNumber}:
 *   post:
 *     summary: Reserve a ticket by seat number
 *     tags: [Tickets]
 *     parameters:
 *       - in: path
 *         name: eventId
 *         required: true
 *         schema:
 *           type: integer
 *         description: The event ID
 *       - in: path
 *         name: seatNumber
 *         required: true
 *         schema:
 *           type: string
 *         description: The seat number
 *     security:
 *       - simpleAuth: []
 *     responses:
 *       200:
 *         description: Ticket reserved successfully
 *       404:
 *         description: Ticket not found
 *       400:
 *         description: Ticket already reserved
 *       401:
 *         description: Forbidden
 */
router.post('/:eventId/seat/:seatNumber', authenticateToken, (req, res) => {
    const { eventId, seatNumber } = req.params;
    const ticket = tickets.find(t => t.seat === seatNumber && t.eventId === parseInt(eventId));

    if (!ticket) return res.status(404).json({ message: 'Ticket not found' });
    if (ticket.reserved) return res.status(400).json({ message: 'Ticket already reserved' });

    ticket.reserved = true;
    ticket.userId = req.user.id;

    res.status(200).json({ message: 'Ticket reserved successfully', ticket });
});

module.exports = router;
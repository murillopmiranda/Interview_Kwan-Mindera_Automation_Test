const express = require('express');
const jwt = require('jsonwebtoken');
const router = express.Router();

const { events, tickets } = require('../data');
const SECRET_KEY = 'secret_key';

const authenticateToken = (req, res, next) => {
    const token = req.headers['authorization'];
    if (!token) return res.sendStatus(403);

    jwt.verify(token, SECRET_KEY, (err, user) => {
        if (err) return res.sendStatus(403);
        req.user = user;
        next();
    });
};

const createTickets = (eventId) => {
    const newTickets = [];
    const rows = 'ABCDEFGHIJ';
    for (let i = 0; i < rows.length; i++) {
        for (let j = 1; j <= 10; j++) {
            newTickets.push({
                seat: `${rows[i]}${j}`,
                eventId,
                reserved: false,
                userId: null
            });
        }
    }
    return newTickets;
};

/**
 * @swagger
 * tags:
 *   name: Events
 *   description: Event management
 */

/**
 * @swagger
 * /events:
 *   post:
 *     summary: Create a new event and automatically generate 100 tickets with seats
 *     tags: [Events]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               name:
 *                 type: string
 *               date:
 *                 type: string
 *                 format: date
 *               location:
 *                 type: string
 *     security:
 *       - simpleAuth: []
 *     responses:
 *       201:
 *         description: Event and tickets created successfully
 *       403:
 *         description: Forbidden
 */
router.post('/', authenticateToken, (req, res) => {
    const { name, date, location } = req.body;
    const eventId = events.length + 1;
    const event = {
        id: eventId,
        name,
        date,
        location,
        organizer: req.user.username
    };
    events.push(event);
    const newTickets = createTickets(eventId);
    tickets.push(...newTickets);

    res.status(201).json({ message: 'Event and tickets created successfully', event, tickets: newTickets });
});

/**
 * @swagger
 * /events:
 *   get:
 *     summary: List all events
 *     tags: [Events]
 *     security:
 *       - simpleAuth: []
 *     responses:
 *       200:
 *         description: List of events
 *       401:
 *         description: Forbidden
 */
router.get('/', authenticateToken, (req, res) => {
    res.json(events);
});

/**
 * @swagger
 * /events/{id}:
 *   get:
 *     summary: Get a specific event by ID
 *     tags: [Events]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *         description: The event ID
 *     security:
 *       - simpleAuth: []
 *     responses:
 *       200:
 *         description: Event details
 *       404:
 *         description: Event not found
 *       401:
 *         description: Forbidden
 */
router.get('/:id', authenticateToken, (req, res) => {
    const event = events.find(e => e.id === parseInt(req.params.id));
    if (!event) return res.status(404).json({ message: 'Event not found' });
    res.json(event);
});

module.exports = router;
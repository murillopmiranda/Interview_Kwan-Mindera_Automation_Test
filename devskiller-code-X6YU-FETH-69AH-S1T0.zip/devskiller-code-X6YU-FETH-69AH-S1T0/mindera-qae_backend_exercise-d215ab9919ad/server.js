const express = require('express');
const app = express();
const port = 3000;

const swaggerJsdoc = require('swagger-jsdoc');
const swaggerUi = require('swagger-ui-express');

app.use(express.json());

const userRoutes = require('./routes/users');
const eventRoutes = require('./routes/events');
const ticketRoutes = require('./routes/tickets');

const swaggerOptions = {
    definition: {
      openapi: '3.0.0',
      info: {
        title: 'API Documentation',
        version: '1.0.0',
      },
      components: {
        securitySchemes: {
          simpleAuth: {
            type: 'apiKey',
            in: 'header',
            name: 'Authorization',
            bearerFormat: 'Authentication Token',
          },
        },
      },
      servers: [
        {
            url: 'http://localhost:3000',
            description: 'Local server'
        }
      ],
    },
    apis: ['./routes/*.js'],
  };
  

const swaggerDocs = swaggerJsdoc(swaggerOptions);
app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerDocs));

app.use((req, res, next) => {
    console.log(`Received ${req.method} request for ${req.path}`);
    next();
});

app.use('/users', userRoutes);
app.use('/events', eventRoutes);
app.use('/tickets', ticketRoutes);

app.listen(port, () => {
    console.log(`Server listening at http://localhost:${port}`);
});

module.exports = app;
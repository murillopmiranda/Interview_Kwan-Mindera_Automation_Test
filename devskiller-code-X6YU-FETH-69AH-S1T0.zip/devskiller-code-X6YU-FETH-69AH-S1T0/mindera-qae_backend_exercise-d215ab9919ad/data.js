const events = [];
const tickets = [];

module.exports = { events, tickets };
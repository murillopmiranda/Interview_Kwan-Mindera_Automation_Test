# Mindera QAE Challenge - BE

![enter image description here](https://image.ibb.co/bXHOB8/rsz_minders_stickers_05.png)

Hello fellow candidate!

Welcome to Mindera's QAE challenge!

Your goal is to make a scalable and robust set of automated tests to an API.

We encourage you to use any approach to cover the functionalities of the API which means you can use any language and frameworks you prefer and you can even modify the provided code to make your tests more robust. 
*This may not be true if it is requested by the recruiter to use a specific language and/or framework.*

When delivering a solution to us we would like to have a solution.txt in this root that should include:

- Instructions on how to set up and run your tests.
- The rationale for choosing the framework and/or structure.
- Potential improvements you suggest for this API.
- If you make any direct changes to the files provided for the local server, you should mention them in this document.

## The Challenge

We did a structured backend that manages events, tickets, and reservations allowing it for creating events, listing available tickets, and reserving tickets. For this we have an API that requires everyone accessing it to be registered and with login made - that will return a token to be used in the events and tickets requests.

Note: This API is not connected with any db which means no data is being persistent - after closing the server every data is lost.

## Installation and Usage

1. Have Node/NPM installed in your 

2. Install dependencies:
    ```sh
    npm install express jsonwebtoken bcryptjs swagger-jsdoc swagger-ui-express
    ```

3. Run server locally:
    ```sh
    node server.js
    ```
    The following log must appear:
    *Mock server listening at http://localhost:3000*

## API Documentation

The API documentation is available via Swagger. When the server is running you can access it at:
*http://localhost:3000/api-docs*

There you will find detailed information about every endpoint and expected behaviour. 

**Happy Testing!**